#please keep width and height below 50

from random import randint

class Grid:
  def __init__(self, w, h):
    self.w = w
    self.h = h
    self.size = w*h
    self.tiles = ["." for i in range(self.size)]

  def index(self, x, y):
    return y*self.w+x
    
  def get(self, x, y):
    return self.tiles[self.index(x, y)]

  def set(self, x, y, c):
    self.tiles[self.index(x, y)] = c

  def print(self):
    for y in range(self.h):
      for x in range(self.w):
        c = self.get(x, y)
        print(c, end = "")
      print()
        

def main():
  w = int(input("Please enter a width: "))
  h = int(input("Please enter a height: "))
  print("Please enter a line of characters below: ")
  cs = input()
  if len(cs) > w * h:
    print("Excessive # of characters")
    return 

  g = Grid(w, h)

  # last step: distribute the characters in cs amongst the grid
  for c in cs:
    while True:
      x = randint(0, w-1)
      y = randint(0, h-1)
      if g.get(x, y) == ".":
        break
    g.set(x, y, c)
      


  g.print()

main()

