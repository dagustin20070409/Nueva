Text Noise Generator

This program asks the user to input a width, a height, and then a line of characters.

It then prints out a grid with the input characters randomly distributed,
and "." for all empty tiles.

To avoid confusion, the program should print a new line before requesting the character input.

Example output/input when running the code:
'''
Please enter a width: 3
Please enter a height: 4
Please enter a line of characters below:
abcdef
.a.
c.b
..f
d.e
'''