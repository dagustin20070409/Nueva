# Word Counter Program

def countWords(file):
  f = open(file)
  s = f.read().lower()
  words = s.split()
  words = [w[:-1] if w[-1]=="," else w for w in words]

  counts = {}
  for w in words:
    if w in counts:
      counts[w] += 1
    else:
      counts[w] = 1

  pairs = list(counts.items())
  pairs.sort(key = lambda p: p[1], reverse = True)
  pairs = pairs[:100]

  for k, v in pairs:
    print(k, v)

while True:
  file = input("Please type a file name: ").strip()
  countWords(file)